import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

Message processData(Message message) {
    def map = message.getProperties()

    // Get values from properties
    def language = map.get("language")
    def oldPayload = map.get("old_payload_json")
    def newPayload = map.get("new_payload_json")

    // Build the JSON structure
    def payload = [
        orchestration_config: [
            module_configurations: [
                llm_module_config: [
                    model_name: "gpt-4.1",
                    model_params: [
                        frequency_penalty: 0,
                        presence_penalty: 0,
                        max_completion_tokens: 24576,
                        temperature: 1
                    ],
                    model_version: "2025-04-14"
                ],
                templating_module_config: [
                    template: [
                        [
                            role: "user",
                            content: [
                                [
                                    type : "text",
                                    text : "Write the email in the language: {{?language_name}}\nHere is the OLD profile payload: {{?old_payload}}\nHere is the NEW profile payload: {{?new_payload}}"
                                ]
                            ]
                        ],
                        [
                            role: "system",
                            content: [
                                [
                                    type : "text",
                                    text : """You are a multilingual assistant. Your task is to compare the old and new payloads of a Business Partner profile and generate a personalized, polite, and human-sounding email to inform the Business Partner about the changes made to their profile. If no changes are found, reply "NO_CHANGES".

Instructions:
- Detect all changes.
- Summarize them clearly.
- Keep it concise and clear.
- Don't generate the subject, only the email body.
- Format it as an HTML (NO code blocks like ```html).
- Ignore change_time change_date changes.
- Address the Business Partner by full name if available.
- Include a friendly closing.
- End the email with the following closing, exactly as shown: Best regards,<br>SAP BTP Adoption & Consumption Center."""
                                ]
                            ]
                        ]
                    ],
                    defaults: [:]
                ],
                filtering_module_config: [
                    input: [
                        filters: [
                            [
                                type: "azure_content_safety",
                                config: [
                                    Hate: 2,
                                    SelfHarm: 2,
                                    Sexual: 2,
                                    Violence: 2,
                                    PromptShield: false
                                ]
                            ]
                        ]
                    ]
                ],
                masking_module_config: [
                    masking_providers: [
                        [
                            type: "sap_data_privacy_integration",
                            method: "pseudonymization",
                            entities: [
                                [type: "profile-credit-card-number"],
                                [type: "profile-driverlicense"],
                                [type: "profile-email"],
                                [type: "profile-sensitive-data"],
                                [type: "profile-ethnicity"],
                                [type: "profile-gender"],
                                [type: "profile-pronouns-gender"],
                                [type: "profile-iban"],
                                [type: "profile-location"],
                                [type: "profile-nationalid"],
                                [type: "profile-nationality"],
                                [type: "profile-org"],
                                [type: "profile-passport"],
                                [type: "profile-person"],
                                [type: "profile-phone"],
                                [type: "profile-political-group"],
                                [type: "profile-sapids-public"],
                                [type: "profile-religious-group"],
                                [type: "profile-sapids-internal"],
                                [type: "profile-ssn"],
                                [type: "profile-sexual-orientation"],
                                [type: "profile-trade-union"],
                                [type: "profile-address"],
                                [type: "profile-url"],
                                [type: "profile-university"],
                                [type: "profile-username-password"]
                            ],
                            mask_grounding_input: [enabled: false],
                            allowlist: []
                        ]
                    ]
                ]
            ]
        ],
        input_params: [
            language_name: language,
            old_payload: oldPayload instanceof String ? oldPayload : JsonOutput.toJson(oldPayload),
            new_payload: newPayload instanceof String ? newPayload : JsonOutput.toJson(newPayload)
        ]
    ]

    // Serialize to JSON string
    def jsonString = JsonOutput.toJson(payload)
    message.setBody(jsonString)

    return message
}
